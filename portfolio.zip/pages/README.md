# Pages Directory

This directory exists to prevent Next.js from trying to use `src/pages` as the Pages Router.

The project uses the App Router located in the `/app` directory at the project root.

DO NOT DELETE THIS DIRECTORY.