"use client";

import { Loader, Stack } from "@mantine/core";
import { useState, useEffect } from "react";
import { IconCode } from "@tabler/icons-react";
import { useTranslations } from "next-intl";

import EmptyState from "@/shared/ui/EmptyState";
import {getAllProjects, Project} from "@/entities/project";
import ProjectTimeline from "@/pages/home/projects/ui/ProjectTimeLine";

export default function ProjectTimelinePage() {
    const t = useTranslations("projects");
    const [projects, setProjects] = useState<Project[]>([]);
    const [isFetching, setIsFetching] = useState(true);

    useEffect(() => {
        fetchProjects();
    }, []);

    const fetchProjects = async () => {
        setIsFetching(true);
        try {
            const result = await getAllProjects();
            setProjects(result);
        } catch (error) {
            console.error("Failed to fetch projects:", error);
        } finally {
            setIsFetching(false);
        }
    };

    if (isFetching) {
        return (
            <Stack align="center" justify="center" h={300}>
                <Loader />
            </Stack>
        );
    }

    if (projects.length === 0) {
        return (
            <EmptyState
                icon={<IconCode size={48} />}
                title={t("emptyTitle")}
                description={t("emptyDesc")}
            />
        );
    }

    return <ProjectTimeline projects={projects} />;
}