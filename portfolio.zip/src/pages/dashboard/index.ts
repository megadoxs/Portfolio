export { default as DashboardPage } from "./DashboardPage"
export { default as EducationPage } from "./education/EducationPage"
export { default as WorkPage } from './work/WorkPage'
export { default as ProjectsPage } from "./projects/ProjectsPage"
export { default as ResumePage } from "./resume/ResumePage"
export { default as ContactPage } from "./contact/ContactPage"
export { default as HobbiesPage } from "./hobbies/HobbiesPage"