export interface Testimonial {
    id: string;
    name: string;
    testimonial: string;
    status: string;
}

export interface TestimonialRequestModel {
    name: string;
    testimonial: string;
    status: string;
}