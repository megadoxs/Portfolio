export interface Hobby {
    id: string;
    name: string;
    picture: string;
}

export interface HobbyRequestModel {
    name: string;
    file: File;
}