'use server'

import {prisma} from "@/shared/lib/prisma/db";
import {Project} from "@/entities/project";

export async function getAllProjects(): Promise<Project[]> {
    return prisma.project.findMany({})
}