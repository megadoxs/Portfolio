export type { Contact, ContactRequestModel } from './model/contact'
export { getContact } from './api/getContact'
export { updateContact } from './api/updateContact'